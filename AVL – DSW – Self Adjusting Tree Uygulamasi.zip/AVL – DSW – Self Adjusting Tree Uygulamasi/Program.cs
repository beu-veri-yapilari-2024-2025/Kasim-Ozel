﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVL___DSW___Self_Adjusting_Tree_Uygulamasi
{
    internal class Program
    {
        public class Node
        {
            public string Data;
            public Node Left;
            public Node Right;
            public int Height;
            public int Frequency;

            public Node(string data)
            {
                Data = data;
                Height = 1;
                Frequency = 0;
                Left = null;
                Right = null;
            }
        }

        public class TreeManager
        {
            public Node Root;
            private CultureInfo trCulture = new CultureInfo("tr-TR");

            public TreeManager()
            {
                Root = null;
            }


            public int GetHeight(Node node)
            {
                if (node == null) return 0;
                return node.Height;
            }

            public int GetBalance(Node node)
            {
                if (node == null) return 0;
                return GetHeight(node.Left) - GetHeight(node.Right);
            }

            public Node RotateRight(Node y)
            {
                Node x = y.Left;
                Node T2 = x.Right;

                x.Right = y;
                y.Left = T2;

                y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;
                x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;

                return x;
            }

            public Node RotateLeft(Node x)
            {
                Node y = x.Right;
                Node T2 = y.Left;

                y.Left = x;
                x.Right = T2;

                x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;
                y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;

                return y;
            }

            public void Insert(string data)
            {
                Root = InsertRec(Root, data);
            }

            private Node InsertRec(Node node, string data)
            {
                if (node == null)
                    return new Node(data);

                int compare = String.Compare(data, node.Data, trCulture, CompareOptions.None);

                if (compare < 0)
                    node.Left = InsertRec(node.Left, data);
                else if (compare > 0)
                    node.Right = InsertRec(node.Right, data);
                else
                    return node;


                node.Height = 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));

                int balance = GetBalance(node);

                if (balance > 1 && String.Compare(data, node.Left.Data, trCulture, CompareOptions.None) < 0)
                    return RotateRight(node);

                if (balance < -1 && String.Compare(data, node.Right.Data, trCulture, CompareOptions.None) > 0)
                    return RotateLeft(node);

                if (balance > 1 && String.Compare(data, node.Left.Data, trCulture, CompareOptions.None) > 0)
                {
                    node.Left = RotateLeft(node.Left);
                    return RotateRight(node);
                }

                if (balance < -1 && String.Compare(data, node.Right.Data, trCulture, CompareOptions.None) < 0)
                {
                    node.Right = RotateRight(node.Right);
                    return RotateLeft(node);
                }

                return node;
            }


            public void PrintInOrder(Node node)
            {
                if (node != null)
                {
                    PrintInOrder(node.Left);
                    Console.Write($"[{node.Data} (F:{node.Frequency})] ");
                    PrintInOrder(node.Right);
                }
            }

            public void PrintLevelOrder()
            {
                if (Root == null) return;
                Queue<Node> queue = new Queue<Node>();
                queue.Enqueue(Root);
                while (queue.Count > 0)
                {
                    int levelCount = queue.Count;
                    while (levelCount > 0)
                    {
                        Node temp = queue.Dequeue();
                        Console.Write(temp.Data + " ");
                        if (temp.Left != null) queue.Enqueue(temp.Left);
                        if (temp.Right != null) queue.Enqueue(temp.Right);
                        levelCount--;
                    }
                    Console.WriteLine();
                }
            }



            public void ApplyDSW()
            {
                CreateBackbone();
                BalanceBackbone();
            }

            public void CreateBackbone()
            {
                Node grandParent = null;
                Node temp = Root;
                Node leftChild;

                while (temp != null)
                {
                    leftChild = temp.Left;
                    if (leftChild != null)
                    {

                        Node pivot = temp;
                        temp = leftChild;
                        pivot.Left = temp.Right;
                        temp.Right = pivot;

                        if (grandParent == null)
                            Root = temp;
                        else
                            grandParent.Right = temp;
                    }
                    else
                    {
                        grandParent = temp;
                        temp = temp.Right;
                    }
                }
            }

            public void BalanceBackbone()
            {
                int nodeCount = 0;
                Node temp = Root;
                while (temp != null)
                {
                    nodeCount++;
                    temp = temp.Right;
                }


                int m = (int)Math.Pow(2, Math.Floor(Math.Log(nodeCount + 1, 2))) - 1;


                MakeRotations(nodeCount - m);

                while (m > 1)
                {
                    m = m / 2;
                    MakeRotations(m);
                }
            }

            private void MakeRotations(int count)
            {
                Node grandParent = null;
                Node parent = Root;
                Node child = Root.Right;

                for (int i = 0; i < count; i++)
                {
                    if (child != null)
                    {

                        parent.Right = child.Left;
                        child.Left = parent;

                        if (grandParent == null)
                            Root = child;
                        else
                            grandParent.Right = child;

                        grandParent = child;
                        parent = parent.Right;
                        if (parent != null)
                            child = parent.Right;
                        else
                            child = null;
                    }
                }
            }



            public void SearchWithFrequency(string key)
            {
                Console.WriteLine($"\n'{key}' aranıyor...");
                Root = SearchAndAdjust(Root, key);
            }

            private Node SearchAndAdjust(Node node, string key)
            {
                if (node == null) return null;

                int compare = String.Compare(key, node.Data, trCulture, CompareOptions.None);

                if (compare == 0)
                {
                    node.Frequency++;
                    return node;
                }
                else if (compare < 0)
                {
                    node.Left = SearchAndAdjust(node.Left, key);
                    if (node.Left != null && node.Left.Frequency > node.Frequency)
                    {
                        node = RotateRight(node);
                    }
                }
                else
                {
                    node.Right = SearchAndAdjust(node.Right, key);
                    if (node.Right != null && node.Right.Frequency > node.Frequency)
                    {
                        node = RotateLeft(node);
                    }
                }

                return node;
            }
        }
            static void Main(string[] args)
            {
                TreeManager tree = new TreeManager();
                string[] inputs = { "S", "E", "L", "İ", "M", "K", "A", "Ç", "T", "I" };

                Console.WriteLine("--- 1. ADIM: AVL AĞACI OLUŞTURULUYOR ---");
                foreach (var s in inputs)
                {
                    tree.Insert(s);
                }

                Console.WriteLine("\n[AVL Ağacı - Level Order (Görsel Yapı)]");
                tree.PrintLevelOrder();

                Console.WriteLine("\n[AVL Ağacı - InOrder (Sıralı)]");
                tree.PrintInOrder(tree.Root);
                Console.WriteLine("\n\n--------------------------------------");

                Console.WriteLine("--- 2. ADIM: DSW ALGORİTMASI UYGULANIYOR ---");
                Console.WriteLine("Bilgi: DSW, ağacı önce Backbone (çizgisel) hale getirir, sonra mükemmel dengeye kavuşturur.");
                tree.ApplyDSW();

                Console.WriteLine("\n[DSW Sonrası - Level Order]");
                tree.PrintLevelOrder();
                Console.WriteLine("\n--------------------------------------");

                Console.WriteLine("--- 3. ADIM: SELF-ADJUSTING (FREQUENCY) İŞLEMLERİ ---");
                Console.WriteLine("Senaryo: Bazı elemanlara sık erişim yapılacak. Frekansı artan düğüm köke yaklaşmalı.");


                tree.SearchWithFrequency("K");
                tree.PrintLevelOrder();

                tree.SearchWithFrequency("K");
                tree.SearchWithFrequency("A");
                tree.SearchWithFrequency("A");
                tree.SearchWithFrequency("A");

                Console.WriteLine("\n[Self-Adjusting Sonrası - Level Order]");
                tree.PrintLevelOrder();

                Console.WriteLine("\n[Self-Adjusting Sonrası - InOrder ve Frekanslar]");
                tree.PrintInOrder(tree.Root);

                Console.ReadLine();
            }
        
    }
}

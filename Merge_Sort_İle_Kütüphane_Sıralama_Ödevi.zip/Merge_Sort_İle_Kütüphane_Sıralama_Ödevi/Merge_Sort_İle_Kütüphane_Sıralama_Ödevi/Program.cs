﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Merge_Sort_İle_Kütüphane_Sıralama_Ödevi
{
class Kitap
    {
        // 📘 Kitap Adı
        public string KitapAdi { get; set; }

        // 📅 Basım Yılı
        public int BasimYili { get; set; }

        public Kitap(string kitapAdi, int basimYili)
        {
            KitapAdi = kitapAdi;
            BasimYili = basimYili;
        }
    }

    class Program
    {
        static void Main()
        {
            // 📚 Kitap Listesi (En az 6 kitap)
            List<Kitap> kitaplar = new List<Kitap>()
        {
            new Kitap("Suç ve Ceza", 1866),
            new Kitap("Sefiller", 1862),
            new Kitap("1984", 1949),
            new Kitap("Kürk Mantolu Madonna", 1943),
            new Kitap("Beyaz Diş", 1906),
            new Kitap("Tutunamayanlar", 1971)
        };

            Console.WriteLine("📌 SIRALAMA ÖNCESİ:");
            KitaplariYazdir(kitaplar);

            // 🔀 Merge Sort ile sıralama
            MergeSort(kitaplar, 0, kitaplar.Count - 1);

            Console.WriteLine("\n📌 SIRALAMA SONRASI (Basım Yılı Artan):");
            KitaplariYazdir(kitaplar);
        }

        // 🔹 Merge Sort
        static void MergeSort(List<Kitap> liste, int sol, int sag)
        {
            if (sol < sag)
            {
                int orta = (sol + sag) / 2;

                MergeSort(liste, sol, orta);
                MergeSort(liste, orta + 1, sag);

                Merge(liste, sol, orta, sag);
            }
        }

        // 🔹 Birleştirme (Merge) İşlemi
        static void Merge(List<Kitap> liste, int sol, int orta, int sag)
        {
            int n1 = orta - sol + 1;
            int n2 = sag - orta;

            List<Kitap> solDizi = new List<Kitap>();
            List<Kitap> sagDizi = new List<Kitap>();

            for (int i = 0; i < n1; i++)
                solDizi.Add(liste[sol + i]);

            for (int j = 0; j < n2; j++)
                sagDizi.Add(liste[orta + 1 + j]);

            int iSol = 0, iSag = 0, k = sol;

            while (iSol < n1 && iSag < n2)
            {
                if (solDizi[iSol].BasimYili <= sagDizi[iSag].BasimYili)
                {
                    liste[k] = solDizi[iSol];
                    iSol++;
                }
                else
                {
                    liste[k] = sagDizi[iSag];
                    iSag++;
                }
                k++;
            }

            while (iSol < n1)
            {
                liste[k] = solDizi[iSol];
                iSol++;
                k++;
            }

            while (iSag < n2)
            {
                liste[k] = sagDizi[iSag];
                iSag++;
                k++;
            }
        }

        // 🔹 Kitapları Yazdırma
        static void KitaplariYazdir(List<Kitap> kitaplar)
        {
            foreach (var kitap in kitaplar)
            {
                Console.WriteLine($"Kitap Adı: {kitap.KitapAdi}, Basım Yılı: {kitap.BasimYili}");
            }
        }
    }
}

